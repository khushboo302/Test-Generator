
var testName, testDuration, testMode, checkboxId, questTypeValue, numberofDivs, i, j, headercheckBoxes, listcheckBoxes, totalMark, copyMode;
var checkboxesId = 1,
	questTypeId = 1,
	state = false,
	arrayChapters = [],
	count = 1,
	countQuestions = 0,
	countMarks = 0;
	var array = [1,2,3,4];	

$.ajax({
	type: 'GET',
	url: 'js/data.xml',
	dataType: 'xml',
	success: function xmlParser(xml){
		$(xml).find('chapter').each(function(){
			/* $('#chapterList').append('<input class="checkBoxes" type="checkbox" id="'+checkboxId+'"><li>' +$(this).text()+ ' </li>'); */
			$('.selectChapters').append('<div id="chapterList"><input class="checkBoxes" type="checkbox" id="'+checkboxesId+'"> '+$(this).attr('num')+'. '+$(this).text()+' </div>');
			checkboxesId = checkboxesId + 1;
		});
		
		$(xml).find('qtype').each(function(){
			$('#questionMode').append('<option class="questType" id='+questTypeId+' value='+$(this).attr('lbl')+'>'+$(this).attr('desc')+'</option>');
			questTypeId = questTypeId + 1;
		});	
	}
});

$('#questionButton').click(function(){
	$('#questionContent, #questTypeHeader').empty();
	questTypeValue = $('.questType:selected').attr('value');
	/* console.log(questTypeValue);
 */
	$('#questionContent').empty();
	var listIdCheck1 = 1;
	for(var i=0; i<=arrayChapters.length - 1; i++){
		var j = arrayChapters[i];
		var headerIdCheck = 1;	
		$('#questionContent').append('<div id="numberofDivsId'+(i+1)+'" class="numberofDivsStyle '+arrayChapters[i]+'"></div>');			
		/* console.log(j); */
		$.ajax({
			type: 'GET',
			url: 'js/data.xml',
			dataType: 'xml',
			ajaxJ: j,
			ajaxI: i,
			success: function xmlParser(xml){
				// Capture the current value of 'i'.
				j = this.ajaxJ; // Reinstate the correct value for 'i'.
				i = this.ajaxI;
				/* alert(i); */
				
				$(xml).find('question[chapter="'+j+'"][type="'+questTypeValue+'"] questTitle').each(function(){
					$('#numberofDivsId'+(i+1)).append('<input class="headercheckBoxes" type="checkbox" id="headerIdCheckBox'+headerIdCheck+'"/><input type="number" class="totalMark" id="totalMark'+(i+1)+'" min="0" disabled/><div class="headerStyle" id="headerStyle'+(i+1)+'">'+(i+1)+'. '+$(this).text()+'</div>');
					headerIdCheck = headerIdCheck + 1;
				});
				$(xml).find('question[chapter="'+j+'"][type="'+questTypeValue+'"] images').each(function(){
					$('#headerStyle'+(i+1)).append('<div><img class="questImages" src="images/'+$(this).text()+'"/></div>');
				});
				$(xml).find('question[chapter="'+j+'"][type="'+questTypeValue+'"] subq').each(function(){
					var questTypetext = $(this).text();
					/* console.log(questTypetext); */
					var countText = (questTypetext.match(/=/g) || []).length;
					/* console.log(countText); */
					var split = questTypetext.split('=');
					$('#numberofDivsId'+(i+1)).append('<ol type="a" id="listId'+(i+1)+'"></ol>');
					var listIdCheck = 1;
					
					for(var s=0; s<=countText; s++){
						/* console.log(split[s]); */
						/* $('#listId'+(i+1)).append('<input class="listcheckBoxes" type="checkbox" id="'+listIdCheck1+'listIdCheckBox'+listIdCheck+'"><li class="listStyle">'+split[s]+'</li>'); */
						$('#listId'+(i+1)).append('<li class="listStyle"><input class="listcheckBoxes '+questTypeValue+'" type="checkbox" id="'+listIdCheck1+'listIdCheckBox'+listIdCheck+'" value="'+split[s]+'">'+split[s]+'</li>'); 
						listIdCheck = listIdCheck + 1;
					}
					listIdCheck1 = listIdCheck1 + 1;
					/* $('#numberofDivsId'+(i+1)).append(''+$(this).text()+''); */			
				});
				
			}
		});
	}
});

$(document).on('change', '.headercheckBoxes', function(){
	headercheckBoxes = $(this).attr('id');
	if($('#' +headercheckBoxes).is(':checked')){
		$('#' +headercheckBoxes).siblings('ol').find('.listcheckBoxes').prop('checked', true);
		countQuestions = countQuestions + $('#' +headercheckBoxes).siblings('ol').find('.listcheckBoxes').prop('checked', true).length;
		
		console.log(countQuestions)
		$('#questSelected').text(countQuestions);
		
		$('#' +headercheckBoxes).siblings('.totalMark').prop('disabled', false);
	} 
	else{
		countQuestions = countQuestions - $('#' +headercheckBoxes).siblings('ol').find('.listcheckBoxes:checked').length;
		console.log(countQuestions)
		$('#questSelected').text(countQuestions);
		$('#' +headercheckBoxes).siblings('ol').find('.listcheckBoxes').prop('checked', false);
		$('#' +headercheckBoxes).siblings('.totalMark').prop('disabled', true);
	}
});

$(document).on('change', '.listcheckBoxes', function(){
	listcheckBoxes = $(this).attr('id');
	if($('#' +listcheckBoxes).is(':checked')){
		$(this).parents('li').parents('ol').siblings('.headercheckBoxes').prop('checked', true);
		countQuestions = countQuestions + $('#' +listcheckBoxes).prop('checked', true).length;
		/* console.log(countQuestions) */
		$('#questSelected').text(countQuestions);
		$(this).parents('li').parents('ol').siblings('.totalMark').prop('disabled', false);
	} 
	else{
		if($('#' +listcheckBoxes).parent().siblings('li').children('input').is(':checked')){
			$('#' +listcheckBoxes).parents('li').parents('ol').siblings('.headercheckBoxes').prop('checked', true);
			countQuestions = countQuestions - $('#' +listcheckBoxes).prop('checked', false).length;
			/* console.log(countQuestions) */
			$('#questSelected').text(countQuestions);
		}
		else{			
			countQuestions = countQuestions - $('#' +listcheckBoxes).prop('checked', false).length;
			console.log(countQuestions)
			$('#questSelected').text(countQuestions);
			$('#' +listcheckBoxes).parents('li').parents('ol').siblings('.headercheckBoxes').prop('checked', false);
			$(this).parents('li').parents('ol').siblings('.totalMark').prop('disabled', true);
		}
	}
});

$(document).on('keyup', '.totalMark', function(){
	totalMark = $(this).val();
		console.log(countMarks);
	/* var totalMarkchange = totalMark;*/
	console.log(totalMark) 
	if(totalMark == 0 && countMarks == 0){
		countMarks = 0;
		console.log(countMarks);
		$('#totalMarks').text(countMarks);
	}
	else if(totalMark == 0){
		countMarks = countMarks;
		$('#totalMarks').text(countMarks);
	}
	else{
		countMarks = countMarks + parseInt(totalMark);
		/* console.log(countMarks); */
		$('#totalMarks').text(countMarks);
	}
});

$('#AddButton').click(function(){
	/* $('.showQuestionStyle').empty(); */
	var questModeCheck = $('#questionMode').select().val();
	/* alert($('.numberofDivsStyle').length); */
	/* for(var i=1; i<=$('.numberofDivsStyle').length; i++){
		var numberofDivsStyle+i = new Array();
		
	} */
	/* var searchIDs = $('.listcheckBoxes:checked').map(function(){
      return $(this).val();
    });
    console.log(searchIDs.get()); */
	console.log(questModeCheck);
	
		var selected = new Array();
		$(".listcheckBoxes:checked").each(function(){
			selected.push(this.value);
		});
		
		
		
		$('.showQuestions').append('<div class="showQuestionStyle" id="'+questModeCheck+'"></div>');
	
		$('#'+questModeCheck).append('<ul id="showQuestionList'+questModeCheck+'"></ul>');
		for(var i=0; i<selected.length; i++){		
			$('#showQuestionList'+questModeCheck).append('<li>'+selected[i]+'</li>')
			console.log(selected[i]);
			
		}

	
	if(questModeCheck == 'picQ'){
		var checkedId;
		var selectedpicQ = new Array();
		$(".listcheckBoxes:checked").each(function () {
			selectedpicQ.push(this.value);
			checkedId = $(this).attr('id');
			console.log(checkedId)
		});
		
		var selectedImage = new Array();
		$(".headercheckBoxes:checked").each(function () {
			selectedImage.push($(this).siblings('.headerStyle').children('div').children('.questImages').attr('src'));
		});
		
		console.log(selectedImage)
		
		$('.showQuestions').append('<div class="showQuestionStyle" id="'+questModeCheck+'"></div>');
	
		$('#'+questModeCheck).append('<ul class="showQuestionList"></ul>');
		for(var i=0; i<selectedpicQ.length; i++){
			$('.showQuestionList').append('<img src="'+selectedImage[i]+'"/>')	
			$('.showQuestionList').append('<li>'+selectedpicQ[i]+'</li>')
			console.log(selectedpicQ[i]);
		}
	}
	
	/* var selectedDiv = new Array();
	$(".headercheckBoxes:checked").each(function () {
		selectedDiv.push($(this).parent('.numberofDivsStyle').attr('class').split(' ')[1]);
	});
	
	var selectedListItem = new Array();
	$(".listcheckBoxes:checked").each(function () {
		selectedListItem.push(this.value);
	});
	
	console.log(selectedDiv)
	console.log(selectedListItem)
	
	for(var i=0; i<selectedDiv.length; i++){
		var j = selectedDiv[i];
		
		$.ajax({
			type: 'GET',
			url: 'js/data.xml',
			dataType: 'xml',
			ajaxJ: j,
			ajaxI: i,
			success: function xmlParser(xml){
				
				j = this.ajaxJ;
				i = this.ajaxI;
			
				
				$(xml).find('question[type="'+questTypeValue+'"] subq').each(function(){
					
					
					
					$('#numberofDivsId'+(i+1)).append('<input class="headercheckBoxes" type="checkbox" id="headerIdCheckBox'+headerIdCheck+'"/><input type="number" class="totalMark" id="totalMark'+(i+1)+'" disabled/><div class="headerStyle" id="headerStyle'+(i+1)+'">'+(i+1)+'. '+$(this).text()+'</div>');
					headerIdCheck = headerIdCheck + 1;
				});
	
			}
		})
	} */
	
	
	
});

$('#back').click(function(){
	$('#div'+count).hide();
	--count;
	if(count == 2){
		if($('.checkBoxes:checked').length == 0){
			alert('Please select Chapters')
		}	
	}		
	countQuestions = 0;
	$('#questSelected').text(0);
	$('#div'+count).show();	
	/* $('#nextButton').show(); */
});

$('#next').click(function(){
	
	testName = $('#testName').val();
	testDuration = $('#testDuration').val();
	testMode = $('#testMode').select().val();
	if($('#testName').val().length == 0 || $('#testDuration').val().length == 0){
		alert('Enter details')
		return false;
	}
	else{
		/* console.log(testName.length);
		console.log(testDuration);
		console.log(testMode); */		
	}
	
	if(count == 2 && $('.checkBoxes:checked').length == 0){
		alert('Please select Chapters');
		return false;		
	}
	if(count == 3){
		copyMode = $('#copyMode').select().val();
		$('#previewName').text(testName);
		$('#previewCopy').text(copyMode);
		$('#previewTime').text(testDuration);
		$('#previewMarks').text();
		var countHeaderCheckBox;
		countHeaderCheckBox = $('.headercheckBoxes:checked').length;
		for(var i =1; i <=countHeaderCheckBox; i++){
			/* alert($('.headercheckBoxes:checked').attr('id')) */
		}
		/* for(var i=0; i<=arrayChapters.length - 1; i++){
		$('#questionContent').append('<div id="numberofDivsId'+(i+1)+'" class="numberofDivsStyle"></div>');
		
		$('.showQuestions').append */
	}
	
	/* if(count < 2){
		$('.showBottomButtons').hide();
	} */
	$('#questionContent').empty();
	
	$('#div'+count).hide();
	++count;
	
	/* console.log('count:' +count); */
	countQuestions = 0;
	$('#questSelected').text(0);
	$('#div'+count).show();
	/* if(){
		alert('Please select Chapters')			
	}	 */
	
	/* $('#backButton').show(); */
	
	/*---Main Index Page---*/
	
	
	
	/*---Chapters Page---*/
	
	/* $('.numberofDivsStyle').show(); */
	/* 
	console.log(arrayChapters); */
	
	arrayChapters.sort(function(a,b) 
	{
	   return a - b;
	});
	/* console.log(arrayChapters); */
	
	

	
});

$('#selectAll').click(function(){
	$('.checkBoxes').each(function(){
		if(!state){
			this.checked = true; 
		}	
		else{
			this.checked = false; 
		}
	});
	
	if(state){
		state = false;
	}
	else{
		state = true;
	}
});



/* $(document).on('click', '.checkBoxes', function(){
	checkboxId = $(this).attr('id');
	if($('#' +checkboxId).is(':checked')){
		console.log($('#' +checkboxId).attr('id'));
		$('#questionContent').append('<div id="numberofDivsId'+checkboxId+'" class="numberofDivsStyle"></div>');
		$.ajax({
			type: 'GET',
			url: 'js/data.xml',
			dataType: 'xml',
			success: xmlParserQuestion
		});
	} 
	else{
		$('#numberofDivsId'+checkboxId).remove();
	}
}); */

$(document).on('change', '.checkBoxes', function(){
	checkboxId = $(this).attr('id');
	if($('#' +checkboxId).is(':checked')){
		arrayChapters.push(checkboxId);
	} 
	else{
		var removeChapter = checkboxId;
		console.log(removeChapter)
		// arrayChapters.splice($.inArray(itemtoRemove, arrayChapters), 1);
		arrayChapters = $.grep(arrayChapters, function(value) {
		  return value != removeChapter;
		});
	}
});

function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
            $('#blah').attr('src', e.target.result);
        }
        reader.readAsDataURL(input.files[0]);
    }
}

$("#imgInp").change(function(){
    readURL(this);
});



/* For refernce */
$('#button1').click(function(){
	$('#questionContent').empty();
	numberofDivs = $('#input1').val();	
	for(i=1; i<=numberofDivs; i++){
		$('#questionContent').append('<div id="numberofDivsId'+i+'" class="numberofDivsStyle"></div>');
	}
});

/* 
for(var i=0; i<10; i++){
   (function(index){
      $.ajax({
       //
       success:function(data){
          $("#p" + index + "_points").html(data);
       }
      });
   })(i);
} */